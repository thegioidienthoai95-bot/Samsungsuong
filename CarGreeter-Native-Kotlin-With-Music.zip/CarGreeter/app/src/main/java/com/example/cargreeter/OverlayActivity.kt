package com.example.cargreeter

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity toàn màn hình hiển thị ảnh chào mừng, có thể mở ngay cả khi
 * điện thoại đang khoá màn hình (giống thông báo cuộc gọi đến).
 */
class OverlayActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        private const val AUTO_CLOSE_MS = 6000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContentView(R.layout.activity_overlay)

        val imageView = findViewById<ImageView>(R.id.imgFullscreen)
        val btnClose = findViewById<Button>(R.id.btnClose)

        val uriString = intent.getStringExtra(EXTRA_IMAGE_URI)
        if (uriString != null) {
            runCatching {
                val uri = Uri.parse(uriString)
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    imageView.setImageBitmap(bitmap)
                }
            }
        }

        btnClose.setOnClickListener { finish() }

        Handler(Looper.getMainLooper()).postDelayed({ finish() }, AUTO_CLOSE_MS)
    }
}
