package com.example.cargreeter

import android.content.Context

object Prefs {
    private const val FILE = "car_greeter_prefs"
    private const val KEY_PHRASE = "phrase"
    private const val KEY_TRIGGER_UNLOCK = "trigger_unlock"
    private const val KEY_TRIGGER_CHARGE = "trigger_charge"
    private const val KEY_TRIGGER_BLUETOOTH = "trigger_bluetooth"
    private const val KEY_IMAGE_URI = "image_uri"
    private const val KEY_SERVICE_ENABLED = "service_enabled"
    private const val KEY_MUSIC = "music"
    private const val DEFAULT_MUSIC = "nhac_chao_buoi_sang"

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getPhrase(context: Context): String = prefs(context).getString(KEY_PHRASE, "Chào sếp, hệ thống xe đã sẵn sàng khởi hành.") ?: "Chào sếp, hệ thống xe đã sẵn sàng khởi hành."
    fun setPhrase(context: Context, value: String) = prefs(context).edit().putString(KEY_PHRASE, value).apply()
    fun isUnlockTriggerEnabled(context: Context) = prefs(context).getBoolean(KEY_TRIGGER_UNLOCK, true)
    fun isChargeTriggerEnabled(context: Context) = prefs(context).getBoolean(KEY_TRIGGER_CHARGE, false)
    fun isBluetoothTriggerEnabled(context: Context) = prefs(context).getBoolean(KEY_TRIGGER_BLUETOOTH, false)
    fun setTriggers(context: Context, unlock: Boolean, charge: Boolean, bluetooth: Boolean) {
        prefs(context).edit().putBoolean(KEY_TRIGGER_UNLOCK, unlock).putBoolean(KEY_TRIGGER_CHARGE, charge).putBoolean(KEY_TRIGGER_BLUETOOTH, bluetooth).apply()
    }
    fun getImageUri(context: Context): String? = prefs(context).getString(KEY_IMAGE_URI, null)
    fun setImageUri(context: Context, uri: String?) = prefs(context).edit().putString(KEY_IMAGE_URI, uri).apply()
    fun isServiceEnabled(context: Context) = prefs(context).getBoolean(KEY_SERVICE_ENABLED, false)
    fun setServiceEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_SERVICE_ENABLED, value).apply()
    fun getMusic(context: Context): String = prefs(context).getString(KEY_MUSIC, DEFAULT_MUSIC) ?: DEFAULT_MUSIC
    fun setMusic(context: Context, value: String) = prefs(context).edit().putString(KEY_MUSIC, value).apply()
}
