package com.example.cargreeter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Dịch vụ chạy nền (Foreground Service) - tương đương phần "đang chạy ngầm"
 * trong bản mô phỏng web. Nó lắng nghe các sự kiện hệ thống mà người dùng
 * đã chọn làm điều kiện kích hoạt, rồi đọc câu chào bằng TextToSpeech và
 * (tuỳ chọn) hiện ảnh toàn màn hình.
 */
class GreetingForegroundService : Service() {

    private var tts: TextToSpeech? = null
    private var receiver: BroadcastReceiver? = null
    private var lastTriggerAt = 0L
    private var mediaPlayer: MediaPlayer? = null

    companion object {
        private const val CHANNEL_ID_SERVICE = "car_greeter_service"
        private const val CHANNEL_ID_ALERT = "car_greeter_alert"
        private const val NOTIF_ID_SERVICE = 1
        private const val NOTIF_ID_ALERT = 2
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(NOTIF_ID_SERVICE, buildServiceNotification())

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("vi", "VN")
            }
        }

        registerTriggerReceiver()
    }

    private fun registerTriggerReceiver() {
        val filter = IntentFilter()
        if (Prefs.isUnlockTriggerEnabled(this)) filter.addAction(Intent.ACTION_USER_PRESENT)
        if (Prefs.isChargeTriggerEnabled(this)) filter.addAction(Intent.ACTION_POWER_CONNECTED)
        if (Prefs.isBluetoothTriggerEnabled(this) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }

        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val now = SystemClock.elapsedRealtime()
                // Avoid double greetings when several car-related broadcasts arrive together.
                if (now - lastTriggerAt < 2500L) return
                lastTriggerAt = now
                triggerGreeting()
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun triggerGreeting() {
        val phrase = Prefs.getPhrase(this)
        playSelectedMusic()
        tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "car_greeting")

        val imageUri = Prefs.getImageUri(this)
        if (!imageUri.isNullOrEmpty()) {
            showFullScreenImage(imageUri)
        }
    }

    private fun playSelectedMusic() {
        val resId = when (Prefs.getMusic(this)) {
            "nhac_chao_nhe_nhang" -> R.raw.nhac_chao_nhe_nhang
            "nhac_chao_nang_luong" -> R.raw.nhac_chao_nang_luong
            else -> R.raw.nhac_chao_buoi_sang
        }
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(this, resId)?.apply {
            setVolume(0.55f, 0.55f)
            setOnCompletionListener { it.release(); if (mediaPlayer === it) mediaPlayer = null }
            start()
        }
    }

    /**
     * Dùng notification có fullScreenIntent - đây là cách chuẩn của Android
     * để mở một Activity toàn màn hình từ nền / qua màn hình khoá.
     */
    private fun showFullScreenImage(imageUri: String) {
        val overlayIntent = Intent(this, OverlayActivity::class.java).apply {
            putExtra(OverlayActivity.EXTRA_IMAGE_URI, imageUri)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, overlayIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Car Greeter")
            .setContentText("Đang hiển thị ảnh chào mừng")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true)
            .setAutoCancel(true)
            .build()

        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID_ALERT, notification)
    }

    private fun buildServiceNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID_SERVICE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Car Greeter đang chạy")
            .setContentText("Đang lắng nghe sự kiện kích hoạt")
            .setOngoing(true)
            .build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID_SERVICE,
                "Trạng thái dịch vụ",
                NotificationManager.IMPORTANCE_LOW
            )
        )

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID_ALERT,
                "Lời chào toàn màn hình",
                NotificationManager.IMPORTANCE_HIGH
            )
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        receiver?.let { runCatching { unregisterReceiver(it) } }
        tts?.stop()
        tts?.shutdown()
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
