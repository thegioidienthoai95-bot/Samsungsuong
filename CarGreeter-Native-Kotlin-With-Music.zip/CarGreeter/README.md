# Car Greeter — Dự án Android (Kotlin)

Ứng dụng tự động đọc lời chào bằng giọng nói khi lên xe, theo phong cách MacroDroid.

## Tính năng
- **Đổi câu chào** tuỳ ý (Text-to-Speech tiếng Việt).
- **Nhiều điều kiện kích hoạt**, chọn được cùng lúc:
  - Mở khoá màn hình
  - Cắm sạc
  - Kết nối Bluetooth (tai nghe/loa/màn hình xe)
- **Hiển thị ảnh toàn màn hình** (kể cả khi máy đang khoá) mỗi khi kích hoạt.
- **Chạy nền (Foreground Service)** + tự khởi động lại sau khi khởi động máy.

## Cách build ra file APK

1. Cài **Android Studio** (bản mới nhất): https://developer.android.com/studio
2. Mở Android Studio → **File → Open** → chọn thư mục `CarGreeter` (thư mục chứa file `settings.gradle`).
3. Chờ Gradle Sync chạy xong (lần đầu cần internet để tải thư viện).
4. Cắm điện thoại Android qua USB, bật **Chế độ nhà phát triển** + **Gỡ lỗi USB**, hoặc dùng máy ảo (AVD).
5. Bấm nút ▶ (Run) để cài thẳng lên máy, HOẶC:
   - Vào **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - File APK sẽ nằm ở: `app/build/outputs/apk/debug/app-debug.apk`
6. Copy file `.apk` đó vào điện thoại và cài đặt (cần bật "Cài đặt ứng dụng không rõ nguồn" nếu cài thủ công).

## Sau khi cài lên máy thật
- Mở app → nhập câu chào, chọn điều kiện kích hoạt, chọn ảnh (nếu muốn) → **Lưu cấu hình** → **Bật Macro**.
- App sẽ xin quyền: Thông báo (Android 13+), Bluetooth (Android 12+).
- Vì đây là ứng dụng chạy nền, một số hãng máy (Xiaomi, Oppo, Vivo, Huawei...) có cơ chế **tự tắt ứng dụng nền** rất mạnh —
  bạn cần vào phần **Cài đặt pin → Không giới hạn nền / Autostart** và bật thủ công cho app "Car Greeter",
  nếu không hệ điều hành có thể tự kill service sau một thời gian.

## Giới hạn cần biết
- Code này được viết thủ công, **chưa được build/compile thử thực tế** (môi trường soạn thảo không có Android SDK/Gradle).
  Khi mở trong Android Studio, nếu Gradle báo lỗi phiên bản plugin/thư viện không khớp, hãy để Android Studio
  tự đề xuất bản cập nhật tương thích (nút "Upgrade" khi hiện thông báo) — đây là chuyện bình thường vì các phiên bản
  công cụ Android thay đổi liên tục.
- Trên Android 10 trở lên, việc mở một Activity toàn màn hình từ nền có giới hạn khá chặt; app dùng cách chuẩn của
  Android (notification kèm `fullScreenIntent`, giống thông báo cuộc gọi đến) để vượt qua giới hạn này một cách hợp lệ.
